Это открытые геоданные из проекта OpenStreetMap в shape-формате.

OpenStreetMap - открытая карта мира, в которой мы можете сразу начать
участвовать, результаты этой работы принадлежат вам
http://openstreetmap.org

Два золотых правила OSM: 
1) Не копируйте у других
2) Получайте удовольствие от работы

Сайт российского сообщества: http://openstreetmap.ru

Лицензия данных: CC-BY-SA http://creativecommons.org/licenses/by-sa/2.0/legalcode
Правила использования данных:
http://wiki.openstreetmap.org/wiki/Legal_FAQ#I_would_like_to_use_OpenStreetMap_maps._How_should_I_credit_you.3F

Ежедневные обновления данных и полное описание: http://gis-lab.info/projects/osm_shp/

Система координат данных: WGS84, проекция: широта/долгота.
